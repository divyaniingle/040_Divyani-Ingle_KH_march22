import java.util.*;
import java.util.ArrayList;
import java.util.Collections;

// class Item
// {
// // Integer itemId;
// // String itemName;
// public static void main(String args[])
// {

// ArrayList<Info> list=new ArrayList<Info>();
// list.add(1,"divyani");
// System.out.printlb(list);
// }
// }
class Item 
{
Integer itemID;
String itemName;
public Item(Integer itemID,String itemName)
{
	this. itemID=itemID;
	this. itemName=itemName;
}
public String toString()
{
	return this. itemID+" "+itemName;
}

public static void main(String args[])
{
	ArrayList<Item> list=new ArrayList<Item>();
	list.add(new Item(3,"Ramesh"));
	list.add(new Item(2,"dhiraj"));
	list.add(new Item(1,"amit"));
	
	//Collections.sort(list);
	System.out.println(list);
	list.add(new Item(7,"adhiraj"));
	list.add(new Item(10,"amey"));
	System.out.println(list);
	//Collections.sort(Item);
	list.remove(0);
	System.out.println(list);
}
}