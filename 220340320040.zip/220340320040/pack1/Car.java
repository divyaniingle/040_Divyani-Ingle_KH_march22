package pack1;
public class Car
{
private int year;
private String make;
private static double speed;

public Car(int year,String make,double speed)
{
this.year=year;
this.make=make;
this.speed=speed;
}
public void setYear(int year)
{
	this.year=year;
}
public int getYear()
{
	return this.year;
}
public void setMake(String make)
{
	this.make=make;
}
public String getMake()
{
	return this.make;
}
public void setSpeed(double speed)
{
	this.speed=speed;
}
public double getSpeed()
{
	return this.speed;
}
public static double accelerate()
{
	
return speed+1;	
//System.out.println("speed for fisrt time"+this.speed);
}
public void display()
{
	System.out.println("yaear is"+this.year);
	System.out.println("make is"+this.make);
	System.out.println("speed is"+this.speed);
	
}
}
