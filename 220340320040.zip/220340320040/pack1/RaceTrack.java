package pack1;
import pack1.Car;
class RaceTrack
{
	public static void main(String args[])
	{
	Car c=new Car(2010,"Porsche",25.0);
	c.display();//displaying information ussing display
	System.out.println("year is"+c.getYear());
	System.out.println("make is"+c.getMake());
	System.out.println("speed is"+c.getSpeed());
	System.out.println("updated speed"+Car.accelerate());
	}
}