package HotelM;
import java.util.*;
import java.time.LocalDateTime;
public class CustomerDetailsDisplay
{
	 static Node head;
     static class Node
  {
     String Name;
	 int Age;
     String Gender;
	 String TravelledFrom;
	 int Occupancy;
	 int forDays;
	 int RoomNo;
	 Node next;

	 Node(String Name, int Age, String Gender, String TravelledFrom, int Occupancy, int forDays, int RoomNo)
	  {
		this.Name = Name;
		this.Age = Age;
		this.Gender = Gender;
		this.TravelledFrom = TravelledFrom;
		this.Occupancy = Occupancy;
		this.RoomNo = RoomNo;
		this.forDays = forDays;
		this.next = null;
	  }
   }
   static Node front = null;
   static Node rear = null;
   
   public static void AddCustomerDetails( ) throws NullPointerException
	{
		Scanner sc = new Scanner(System.in);
		System.out.println( );
        System.out.println("--------------------------------------------------------------------RECEPTION DATA BASE-----------------------------------------------------------------");
		System.out.println( );
		
	try
	{
		System.out.print("ENTER NAME OF GUEST : ");
		String Name = sc.nextLine( );
		System.out.print("ENTER AGE OF GUEST : ");
		int Age = sc.nextInt( );
		System.out.print("ENTER GENDER OF GUEST : ");
		String Gender = sc.next( );
		sc.nextLine( );
		System.out.print("GUEST HAS TRAVELLED FROM : ");
		String TravelledFrom = sc.nextLine( );
		System.out.print("GUEST HAS A BOOKING OF : ");
		int Occupancy = sc.nextInt( );
		System.out.print("BOOKING OF (NUMBER OF ODD DAYS) : ");
		int forDays = sc.nextInt( );
		System.out.print("GUEST IS ALLOCATED ROOM NO. : ");
		int RoomNo = sc.nextInt( );
		System.out.println( );
		
		
			Node new_node = new Node(Name, Age, Gender, TravelledFrom, Occupancy,forDays,RoomNo);
		
		if(front == null)
		{
			front = new_node;
			rear = new_node;
		}
		else
		{
			rear.next = new_node;
			rear = new_node;
		}
		}
		catch(Exception e)
		{
			System.out.println("WRONG INPUT");
		}
	}
	
	public static void DisplayCustomerDetails( ) 
	{
		try
		{
		Node temp = front;
		System.out.println("----------------------------------------------------------------------------------MESSAGE TO CUSTOMER-------------------------------------------------------------------------------");
		LocalDateTime time = LocalDateTime.now( );
		System.out.println( );
		System.out.println("WELCOME " +temp.Name);
	    System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		System.out.printf("%-10s %-15s %-15s %-15s %-15s %-15s %-15s %-15s\n","NAME","DATE&TIME","AGE","GENDER","TRAVELLED_FROM","OCCUPANCY","ROOM_NO","STAY_DAYS");
		System.out.println( );
			while(temp != null)
			{
		      System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		      System.out.printf("%-10s %-15s %-15s %-15s %-15s %-15d %-15d %-15d\n",temp.Name,time,temp.Age,temp.Gender,temp.TravelledFrom,temp.Occupancy,temp.RoomNo,temp.forDays);
		      System.out.println( );
		      System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		      temp = temp.next;
			}
	}
	catch(Exception e)
	{
		System.out.println("NO CUSTOMER ADDED");
	}
}
	
public static void main(String args[ ]) throws NullPointerException
	{
		AddCustomerDetails( );
		DisplayCustomerDetails( );
	}
}
	

