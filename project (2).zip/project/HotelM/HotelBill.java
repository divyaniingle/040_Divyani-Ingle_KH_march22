package HotelM;

class HotelBill
{ 
 static double total_amt=0.0;
public static void calBill()
{   

     
	 System.out.println("--------------------------------------------------------------------------------------");
	 System.out.println("your total ammount ot pay");
	 total_amt=Roombooking.roomAmount+foodOrder.amt;
	System.out.println("--------------------------------------------------------------------------------------");
	 System.out.println(total_amt);
	 System.out.println("--------------------------------------------------------------------------------------");
	System.out.println();
}
	

}