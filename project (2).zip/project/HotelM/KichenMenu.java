package HotelM;
import java.util.*;
import HotelM.LoginPage;
import HotelM.CustomerDetailsDisplay;
public class KichenMenu
{
	static Node head;
static class Node
{
	String item_name;
	double item_price;
	Node next;
	Node prev;
	Node(String item_name,double item_price)
	{
		this.item_name=item_name;
		this.item_price=item_price;
		this.next=null;
		this.prev=null;
	}
	
}
public static void creation()
{
	Scanner sc=new Scanner(System.in);
	String item_name;
	double item_price=0.0;
	//boolean flag=true;
	int n;
do{
	
		
	System.out.println("enter the name of new Item ");
	item_name=sc.nextLine();
	 boolean result=item_name.matches("[a-zA-Z]+");
	 if(result==false)
	 {   
 
        // flag=false;
		 System.out.println("you have entered WRONG INPUT !!!");
		 	
	 }

	sc.nextLine();
	try{
    System.out.println("enter the price of new item ");
	item_price=sc.nextDouble();    
	sc.nextLine();
	}
	catch(InputMismatchException e)
	{
		System.out.println("WRONG INPUT");
	}
	Node new_node=new Node(item_name,item_price);
	if(head==null)
	{
		head=new_node;
	}
	else
	{
		head.prev=new_node;
		new_node.next=head;
		head=new_node;
	}
	System.out.println("If you want to add more item PRESS any nubmer other than 1");
	n=sc.nextInt();
	sc.nextLine();
	}while(n!=1);
	
	
}
public static void insertAtEnd()
{   
    
	String item_name;
	double item_price=0.0;
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the name of new Item ");
	item_name=sc.nextLine();
	 boolean result=item_name.matches("[a-zA-Z]+");
	 if(result==false)
	 {
		 System.out.println("you have entered WRONG INPUT !!!");
	 }
	sc.nextLine();
	try{
    System.out.println("enter the price of new item ");
	item_price=sc.nextDouble();
	}catch(InputMismatchException e)
	{
		System.out.println("WRONG INPUT");
	}
	Node new_node=new Node(item_name,item_price);
	Node n=head;
	if(head==null)
	{
		new_node.prev=null;
		head=new_node;
	}
	else 
	{
		while(n.next!=null)
		{
			n=n.next;
		}
		n.next=new_node;
		new_node.prev=n;
	}
}
public static void insertAfter()
 {
	 Scanner sc=new Scanner(System.in);
	 System.out.println("Enter the position where you wantb to add new item");
	 int position=sc.nextInt();
	 String item_name;
	double item_price=0.0;
	
	System.out.println("enter the name of new Item ");
	item_name=sc.nextLine();
	sc.nextLine();
	boolean result=item_name.matches("[a-zA-Z]+");
	if(result==false)
	{
		System.out.println("you have entered WRONG INPUT !!!");
	}
	try{
    System.out.println("enter the price of new item ");
	item_price=sc.nextDouble();
	}catch(InputMismatchException e)
	{
		System.out.println("WRONG INPUT");
	}
	Node new_node=new Node(item_name,item_price);
	 Node n=head;
	 Node ptr=n.next;
	 for(int i=1;i<position-1;i++)
	 {
		 n=ptr;
		 ptr=ptr.next;
	 }
	 new_node.prev=n;
	 new_node.next=ptr;
	 n.next=new_node;
	 ptr.prev=new_node;
	
 }
public static void deleteAtPosition()
 {
	 int position=0;
	 Scanner sc=new Scanner(System.in);
	
	  if(head==null)
	 {
		 System.out.println("list is already empty !!!");
	 }
	 else 
	 {
	try
	{
	 System.out.println("Enter the position of  item you want to delete new item");
	 position=sc.nextInt();
	}
	catch(Exception e)
	{
		System.out.println("wrong input");
	}
	 Node n=head;
	 Node ptr=n.next;
	 for(int i=1;i<position-1;i++)
	 {
		 n=ptr;
		 ptr=ptr.next;
	 }
	 n.next=ptr.next;
	 ptr.next.prev=n;
	 }
 }
public static void display()
{
	Node n=head;
	if(head==null)
	{
		System.out.println("your menu list is empty !!!");
	}
	
	else
	{
		System.out.println("_____________________________________________________");
		System.out.printf("%-30s%s\n","item_name","item_price");
		System.out.println("_____________________________________________________");
	while(n!=null)
	{
		System.out.printf("%-30s%s\n",n.item_name,n.item_price);
		
		n=n.next;
	}	
        System.out.println("_____________________________________________________");	
	}
}

public static void main(String args[])
{
	 Scanner sc=new Scanner(System.in);
	KichenMenu k=new KichenMenu();
	 k.creation();
	 k.display();
	System.out.println("press 1 if youb want add item at end lof list");
	 int n=sc.nextInt();
	if(n==1)
	{
	 k.insertAtEnd();
	}
	 k.display();
	 System.out.println("press 1 if youb want add item in the position of list");
	 int m=sc.nextInt();
	 if(m==1)
	 {
		 k.insertAfter();
	 }
	k.display();
	
	System.out.println("press 1 if youb want add item in the position of list");
 int l=sc.nextInt();
	if(l==1)
	{
	 k.deleteAtPosition();
	 }
	k.display();
 }

}