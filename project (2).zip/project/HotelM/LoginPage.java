package HotelM;
import java.util.*;
//import HotelM.KichenMenu;
//import HotelM.Roombooking;
//import static HotelM.Roombooking.head;

public class LoginPage
{   
 static Scanner sc=new Scanner(System.in);
	
static void dashboard()
{
	int choice=0;
	do{
	
System.out.println("1. ADD CUSTOMER");
System.out.println("2. CUSTOMER DETAILS");
System.out.println("3. KITCHEN ");
System.out.println("4. FOOD ORDER ");
System.out.println("5. ROOM");
System.out.println("6. BILL");
System.out.println("7. EXIT");

System.out.println("Enter your CHOICE from above :" );
try
{
choice=sc.nextInt();
}catch(InputMismatchException e)
{
	System.out.println("WRONG INPUT  !!!!");
}
switch(choice)
{
	case 1:CustomerDetailsDisplay.AddCustomerDetails( );
	  LoginPage.dashboard();
    break;
	case 2:CustomerDetailsDisplay.DisplayCustomerDetails( );
	LoginPage.dashboard();
	break;
	case 3:Scanner sc=new Scanner(System.in);
	 int choice1;
	
	 
	       System.out.println("1.ADD TODAYS MENU");
		   System.out.println("2.ADD MORE MENU IN POSITION");
	       System.out.println("3.DISPLY TODAYS MENU");
		   System.out.println("4.DELETE MENU");
		   choice1=sc.nextInt();
	 
		   switch(choice1)
		   {
			   case 1:KichenMenu.creation();
			   LoginPage.dashboard();
			   break;
			   case 2:KichenMenu.insertAfter();
			    LoginPage.dashboard();
			   break;
			   case 3:KichenMenu.display();
			    LoginPage.dashboard();
			   break;
			   case 4:KichenMenu.deleteAtPosition();
			    LoginPage.dashboard();
			   break;
		   }
		   
	LoginPage.dashboard();
	break;
	case 4:
	         foodOrder.showMenuCard();
			  foodOrder.OrderFood();
			  LoginPage.dashboard();
	LoginPage.dashboard();
	break;
	case 5:         
	Roombooking.addlast(1,"Single Ac   ",2000);
	Roombooking.addlast (2,"Single Ac   ",2000);
	Roombooking.addlast(3,"Single Ac   ",2000);
	 Roombooking.addlast(4,"Single Ac   ",2000);
	Roombooking.addlast(5,"Single Ac   ",2000);
	Roombooking.addlast(6,"Double Ac   ",3500);
	Roombooking.addlast(7,"Double Ac   ",3500);
	Roombooking.addlast(8,"Double Ac   ",3500);
	 Roombooking.addlast(9,"Double Ac   ",3500);
	 Roombooking.addlast(10,"Double Ac   ",3500);
	 Roombooking.addlast(11,"Suite       ",6000);
	Roombooking.addlast(12,"Suite       ",6000);
	        Roombooking.display(Roombooking.head);
			
	        Roombooking.selectroom();
			 Roombooking.display(Roombooking.head);
			Roombooking.Addroom(Roombooking.head);
			 Roombooking.display(Roombooking.head);
			 
    
	
	
	break;
	case 6:HotelBill.calBill();
	//LoginPage.dashboard();
	break;
	
	
}
}while(choice==6);
}	
public static void main(String args[])
{
LoginPage lp=new LoginPage();
//int choice=0;
System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------");
System.out.println("                                                                     HOTEL RADISSON,MUMBAI");
System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------");
System.out.println();
System.out.println("HOTEL STAFF LOGIN");
System.out.println();

boolean flag=false;
do
{     
		  System.out.println("***********************************************");
	      System.out.print("ENTER USERNAME : ");
          String username1=sc.nextLine();
          System.out.print("ENTER PASSWORD : ");
          String password1=sc.nextLine();
		  System.out.println();
          System.out.println("***********************************************");

if(("dishi123".equals(username1))&&("12345".equals(password1)))
{
	System.out.println("Access Granted....");
	flag=true;
    LoginPage.dashboard();

}
  else
	 System.out.println("Please enter correct credentials....");
}while(flag==false);  
 
}
}

