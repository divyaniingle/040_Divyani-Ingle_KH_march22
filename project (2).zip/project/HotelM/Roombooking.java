package HotelM;
import java.util.*;
public class Roombooking
{	
	public static Node head=null;
	public static Node demo;
	public static Node new_node1;
	public static double roomAmount=0.0;
	
	static class Node
	{
		String data;
		int amount;
		int no;
		Node next;
		Node prev;
		
		Node(int no,String d, int amount)
		{   
            this.no=no;
			this.data = d;
			this.amount=amount;
			next = null;
			prev = null;
		}
	}
	
    static void addlast(int no,String new_data,int amount){
		
		Node new_node = new Node(no,new_data,amount);
		
		Node n = head;
		new_node.next = null;
		if(head == null){
			new_node.prev = null;
			head = new_node;
			return;
		}
		while(n.next != null){
			n=n.next;
		}
		n.next = new_node;
		new_node.prev = n;		
}
static void display(Node head)
{
	
	Node n=head;
	System.out.println("\tRoom no\t  Room Type   \t\t\tPrice");
	System.out.println("========================================================================");
	while( n != null)
	{
		System.out.println("\t"+n.no+"\t  "+n.data+ "\t\t\t"+n.amount);
		n=n.next;
	}
}
public static void deletion( ){
	int data, n;
	Scanner sc = new Scanner(System.in);
	
	if(head == null)
			{
				System.out.println("All Rooms are booked");
				return;
			}
			else{
				System.out.println("Enter the room number to comform booking ");
					int p = sc.nextInt();
					if(p<=5)
					{
						 roomAmount=2000.00;
						System.out.println("Amount to pay"+roomAmount);
					}
					else if(p>5 && p<=10)
					{
						roomAmount=3500.00;
						System.out.println("Amount to pay"+roomAmount);
					}
					else 
					{
					roomAmount=6000.00;
						System.out.println("Amount to pay"+roomAmount);	
					}
					
					if(p==1){
						head=head.next;
						return;
					}
					Node temp2 = head;
					Node deletedNode=temp2;
					Node ptr = temp2.next;
					for(int i = 1; i<(p-1); i++)
					{
						temp2 = ptr;
						ptr = ptr.next;
					}
				     temp2.next = ptr.next;
					 ptr.next.prev = temp2;
				
			}
	}	

  static void selectroom(){
		System.out.println("Select the Room that you want to Book ");
		
		deletion();
}
static void insertroom(){
	
	   // Node new_node1;
		String data;
		int amount;
		int no;
	System.out.println("Enter the room no to add : ");
	Scanner sc = new Scanner(System.in);
	    int p = sc.nextInt();
		//Node new_node1;
		switch (p){
			case 1 :{ new_node1 = new Node(1,"Single Ac   ",2000);break;}
			case 2 :{new_node1 = new Node(2,"Single Ac   ",2000);break;}
			case 3 :{new_node1 = new Node(3,"Single Ac   ",2000);break;}
			case 4 :{new_node1 = new Node(4,"Single Ac   ",2000);break;}
			case 5 :{new_node1 = new Node(5,"Single Ac   ",2000);break;}
			case 6 :{new_node1 = new Node(6,"Double Ac   ",3500);break;}
			case 7 :{new_node1 = new Node(7,"Double Ac   ",3500);break;}
			case 8 :{new_node1 = new Node(8,"Double Ac   ",3500);break;}
			case 9 :{new_node1 = new Node(9,"Double Ac   ",3500);break;}
			case 10 :{new_node1 = new Node(10,"Double Ac   ",3500);break;}
			case 11:{new_node1 = new Node(11,"Suite       ",6000);break;}
			case 12:{new_node1 = new Node(12,"Suite       ",6000);break;}

		}
		//Node new_node = new Node(data);
		Node temp1 = head;
		Node ptr = temp1.next;
		for(int i = 1; i<(p-1); i++)
		{
			temp1 = ptr;
			ptr = ptr.next;
		}
	   new_node1.prev = temp1;
	   new_node1.next = ptr;
	   temp1.next = new_node1;
	   ptr.prev = new_node1;
						
}
static void Addroom(Node demo){
	
	System.out.println("enter the choice");
	System.out.println("enter 1 = To display Available Rooms");
	System.out.println("enter 2 = To Add Rooms");
	System.out.println("enter 0 = To Exist");
	Scanner sc1 = new Scanner(System.in);
	int choice1 =sc1.nextInt();
	switch (choice1){
		case 1 :{
			display(demo);
			Addroom(demo);
			break;
		}
		case 2 :{
			insertroom();
			display(demo);
			Addroom(demo);
			//display(demo);
			break;}
		
		case 0:{
			LoginPage.dashboard();;
		}
		
		
			
	}
	
}

public static void main(String args[]){
	
	Roombooking d1 = new Roombooking();
	
	 d1.addlast(1,"Single Ac   ",2000);
	d1.addlast(2,"Single Ac   ",2000);
	d1.addlast(3,"Single Ac   ",2000);
	 d1.addlast(4,"Single Ac   ",2000);
	d1.addlast(5,"Single Ac   ",2000);
	d1.addlast(6,"Double Ac   ",3500);
	d1.addlast(7,"Double Ac   ",3500);
	d1.addlast(8,"Double Ac   ",3500);
	 d1.addlast(9,"Double Ac   ",3500);
	 d1.addlast(10,"Double Ac   ",3500);
	 d1.addlast(11,"Suite       ",6000);
	d1.addlast(12,"Suite       ",6000);
	
	demo= d1.head;
	d1.display(d1.head);
	System.out.println();
	
	d1.selectroom();

	
	d1.Addroom(demo);
	

		
}

}