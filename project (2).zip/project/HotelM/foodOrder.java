package HotelM;
import java.util.*;
import HotelM.LoginPage;
public class foodOrder{
	static float amt=0.0f;
    static String FOOD_ITEM;
	static float PRICE;
	static Scanner sc = new Scanner(System.in);
	public static void showMenuCard()
	{
		 System.out.println("----------------------------------------------------------WELCOME TO RADISSON DINER-----------------------------------------------------------------");
		System.out.println( );
		 System.out.println("----------------------------------------------------------------DISPLAY MENU------------------------------------------------------------------------");
		System.out.println( );
		System.out.printf("%50s %45s" , "FOOD_ITEM" , "PRICE");
		 System.out.println( );
		 System.out.println( );
	
		System.out.printf("%50s %45.2f\n" , "French_Fries" , 150.00f);
		 System.out.println( );
		 System.out.printf("%50s %45.2f\n" , "Chicken_Kebab" , 250.00f);
		 System.out.println( );
		 System.out.printf("%50s %45.2f\n" , "Butter_Paneer" , 400.00f);
		 System.out.println( );
		 System.out.printf("%50s %45.2f\n" , "Butter_Chicken" , 600.00f);
		 System.out.println( );
		 System.out.printf("%50s %45.2f\n" , "Chapati" , 30.00f);
		 System.out.println( );
		System.out.printf("%50s %45.2f\n" , "Rice" , 300.00f);
		 System.out.println( );
		 System.out.printf("%50s %45.2f\n" , "Pizza" , 450.00f);
		System.out.println( );
		 System.out.printf("%50s %45.2f\n" , "Noodles", 250.00f);
		 System.out.println( );
		 System.out.printf("%50s %45.2f\n" , "Gulab_Jamun" , 200.00f);
		 System.out.println( );
		 System.out.printf("%50s %45.2f\n" , "Chocolate_IceCream" , 100.00f);
		 System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------" );
		
	}
	public static void OrderFood()
	{  try{
		while(true)
		{
			
			System.out.println("TO ORDER STARTERS PRESS 1");
			System.out.println("TO ORDER MAIN COURSE PRESS 2");
			System.out.println("TO ORDER CONTINENTAL PRESS 3");
			System.out.println("TO ORDER DESSERTS PRESS 4");
			System.out.println("To EXIT THE MENU PRESS 5");
			System.out.println( );
			
			System.out.println("Enter your choice : ");
			int choice = sc.nextInt( );
			System.out.println( );
			
			switch(choice)
			{
			
			
			case 1: System.out.println("WELCOME TO THE STARTERS SECTION");
			Starters( );
			break;
			
			case 2: System.out.println("WELCOME TO THE MAIN COURSE SECTION");
			Main_Course( );
			break;
			
			case 3: System.out.println("WELCOME TO THE CONTINENTAL SECTION");
			Continental( );
			break;
			
			case 4: System.out.println("WELCOME TO THE DESSERTS SECTION");
			Desserts( );
			break;	
            case 5: 
			 LoginPage.dashboard();
			break;				
			
			default: 
			System.out.println("INCORRECT INPUT!! Please re-enter choice from our menu");
			System.out.println();
			}
		}
	}catch(InputMismatchException e)
	{
		System.out.println("WRONG INPUT");
	}
	}
	
	// public static void main(String args [ ]){
		
		

	// }

	
		public static void Starters( )
		{
			try{
	    int quant=0;
		System.out.println("THE STARTERS MENU INCLUDES : ");
		System.out.println("French_Fries : Medium");
		System.out.println("Enter the quantity for French_Fries:");
		int quant2=sc.nextInt();
		System.out.println("Chicken_Kebab : 6 pieces");
		System.out.println("Enter the quantity for chicken kebab:");
		int quant3=sc.nextInt();
		amt=quant2*150.00f+quant3*250.00f;
		System.out.println("Amount to pay :"+amt);
		System.out.println( );
			}catch(InputMismatchException e)
			{
				System.out.println("WRONG INPUT !!!");
			}
		}
		
		public static void Main_Course( ){
			try{
		System.out.println("THE MAIN COURSE MENU INCLUDES : ");
		System.out.println("Butter_Paneer : Full_Plate");
		System.out.println("Enter the quantity for butter paneer:");
		int quant4=sc.nextInt();
		System.out.println("Butter_Chicken : 3 pieces");
		System.out.println("Enter the quantity for butter chicken:");
		int quant5=sc.nextInt();
		System.out.println("Chapati : 4");
		System.out.println("Enter the quantity for chapati:");
		int quant6=sc.nextInt();
		System.out.println("Rice");
		System.out.println("Enter the quantity for rice:");
		int quant7=sc.nextInt();
		System.out.println( );
		amt=quant4*400.00f+quant5*600.00f+quant6*30.00f+quant7*300.00f;
		System.out.println("Amount to pay :"+amt);
			}catch(InputMismatchException e)
			{
				System.out.println("WRONG INPUT !!!!");
			}
		}
		
		public static void Continental( ){
			try{
		System.out.println("THE CONTINENTAL MENU INCLUDES : ");
		System.out.println("Pizza : Large");
		System.out.println("Enter the quantity for pizza:");
		int quant8=sc.nextInt();
		System.out.println("Noodles : Full_Plate");
		System.out.println("Enter the quantity for noodles:");
		int quant9=sc.nextInt();
		System.out.println( );
		amt=quant8*450.00f+quant9*250.00f;
		System.out.println("Amount to pay :"+amt);
			}catch(InputMismatchException e)
			{
				System.out.println("WRONG INPUT !!!");
			}
		
		}
		
		public static void Desserts( ){
			try{
		System.out.println("THE DESSERTS MENU INCLUDES : ");
		System.out.println("Gulab_Jamun : 2 pieces");
		System.out.println("Enter the quantity for gulab jamun:");
		int quant10=sc.nextInt();
		System.out.println("Chocolate_IceCream");
		System.out.println("Enter the quantity for icecream:");
		int quant11=sc.nextInt();
		 amt=quant10*200.00f+quant11*100.00f;
		System.out.println("Amount to pay :"+amt);
		System.out.println();
			}catch(InputMismatchException e)
			{
				System.out.println("WRONG INPUT !!!");
			}
    }
}